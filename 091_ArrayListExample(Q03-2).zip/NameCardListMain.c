#include<stdio.h>
#include<string.h>
#include"ArrayList.h"
#include"NameCard.h"

int main(){
	List list;
	NameCard *pcard;
	ListInit(&list);

	pcard = MakeNameCard("Moonsung", "0435-815-199");
	LInsert(&list, pcard);

	pcard = MakeNameCard("Hannah", "0435-815-335");
	LInsert(&list, pcard);

	pcard = MakeNameCard("Omok", "010-2936-3136");
	LInsert(&list, pcard);

	printf("���� �������� ��: %d \n", LCount(&list));

	if(LFirst(&list, &pcard)){
		if(!NameCompare(pcard,"Omok"))
			ShowNameCardInfo(pcard);
		while(LNext(&list, &pcard)){
			if(!NameCompare(pcard,"Omok"))
				ShowNameCardInfo(pcard);
		}
	}

	if(LFirst(&list, &pcard)){
		if(!NameCompare(pcard,"Hannah"))
			ChangePhoneNum(pcard,"010-9963-8845");
		while(LNext(&list, &pcard)){
			if(!NameCompare(pcard,"Hannah"))
				ChangePhoneNum(pcard,"010-9963-8845");
		}
	}

	if(LFirst(&list, &pcard)){
		if(!NameCompare(pcard,"Moonsung")){
			pcard=LRemove(&list);
			free(pcard);
		}
		while(LNext(&list, &pcard)){
			if(!NameCompare(pcard,"Moonsung")){
				pcard=LRemove(&list);
				free(pcard);
			}
		}
	}
	printf("\n���� �������� ��: %d \n", LCount(&list));
	if(LFirst(&list, &pcard)){
		ShowNameCardInfo(pcard);
		while(LNext(&list, &pcard)){
			ShowNameCardInfo(pcard);
		}
	}
	return 0;
}