#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"NameCard.h"
/*
typedef struct __namecard
{
	char name[NAME_LEN];
	char phone[PHONE_LEN];
} NameCard;
*/

NameCard *MakeNameCard(char *name, char *phone){
	NameCard *NC;
	NC = (NameCard*)malloc(sizeof(NameCard));
	strcpy(NC->name, name);
	strcpy(NC->phone, phone);
	
	return NC;
}

void ShowNameCardInfo(NameCard *pcard){
	printf("�̸�: %s \n",pcard->name);
	printf("��ȭ��ȣ: %s \n",pcard->phone);
}
int NameCompare(NameCard *pcard, char *name){
	return strcmp(pcard->name, name);	// ������ 0
}
void ChangePhoneNum(NameCard *pcard, char *phone){
	strcpy(pcard->phone, phone);
}